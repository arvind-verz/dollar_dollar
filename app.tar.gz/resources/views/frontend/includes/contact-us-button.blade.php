<div class="ps-call-in-action bg--cover" data-background="img/bg/contact.jpg">
    <div class="container">
        <div class="ps-section__content"><img src="img/icons/phone.png" alt="">

            <h3>Contact Us <span>Now</span>!</h3>

            <p>Curabitur aliquet quam id dui posuere blandit diam. Praesent sapien massa, <br> convallis a
                pellentesque nec, egestas non si nisi.</p><a class="ps-btn ps-btn--yellow" href="#">Send enquiry</a>
        </div>
    </div>
</div>